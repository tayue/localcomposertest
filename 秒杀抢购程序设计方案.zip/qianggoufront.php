<!DOCTYPE html>
<html>
<head lang="en">
    <meta charset="UTF-8">
    <title>秒杀！</title>
    <script src="https://cdn.bootcss.com/jquery/2.1.1/jquery.min.js"></script>

</head>
<body>
<div class="jingshan">
    <span id="timebox">01天01时01分01秒</span>
</div>
</body>

<script type="text/javascript">
    //动态加载js文件
    document.write("<s" + "cript type='text/javascript' src='js/nocdn.js?ver=" + Math.random() + "'></s" + "cript>");
</script>
</html>
<?php ?>
